import { Link } from "react-router-dom";
import { Shield } from "lucide-react";

const Footer = () => {
  return (
    <footer className="border-t bg-card py-12">
      <div className="container">
        <div className="grid gap-8 md:grid-cols-4">
          <div className="space-y-4">
            <Link to="/" className="flex items-center gap-2">
              <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-primary">
                <Shield className="h-5 w-5 text-primary-foreground" />
              </div>
              <span className="text-xl font-bold">MediLedger AI</span>
            </Link>
            <p className="text-sm text-muted-foreground">
              Decentralized healthcare records powered by blockchain and AI 
              for rural communities worldwide.
            </p>
          </div>

          <div>
            <h4 className="mb-4 font-semibold">Product</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link to="/#features" className="hover:text-primary">Features</Link></li>
              <li><Link to="/dashboard" className="hover:text-primary">Dashboard</Link></li>
              <li><Link to="#" className="hover:text-primary">Pricing</Link></li>
              <li><Link to="#" className="hover:text-primary">Integrations</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 font-semibold">Resources</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link to="#" className="hover:text-primary">Documentation</Link></li>
              <li><Link to="#" className="hover:text-primary">API Reference</Link></li>
              <li><Link to="#" className="hover:text-primary">Support</Link></li>
              <li><Link to="#" className="hover:text-primary">Community</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="mb-4 font-semibold">Legal</h4>
            <ul className="space-y-2 text-sm text-muted-foreground">
              <li><Link to="#" className="hover:text-primary">Privacy Policy</Link></li>
              <li><Link to="#" className="hover:text-primary">Terms of Service</Link></li>
              <li><Link to="#" className="hover:text-primary">HIPAA Compliance</Link></li>
              <li><Link to="#" className="hover:text-primary">Security</Link></li>
            </ul>
          </div>
        </div>

        <div className="mt-12 flex flex-col items-center justify-between gap-4 border-t pt-8 md:flex-row">
          <p className="text-sm text-muted-foreground">
            © 2024 MediLedger AI. All rights reserved.
          </p>
          <div className="flex items-center gap-6 text-sm text-muted-foreground">
            <span>🔒 End-to-End Encrypted</span>
            <span>✓ HIPAA Compliant</span>
            <span>🌍 Global Ready</span>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
