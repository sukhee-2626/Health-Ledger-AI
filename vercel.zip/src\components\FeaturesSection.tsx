import { 
  Shield, 
  Lock, 
  Brain, 
  Globe, 
  Wifi, 
  BarChart3,
  UserCheck,
  FileText
} from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";

const features = [
  {
    icon: Shield,
    title: "Blockchain Security",
    description: "Immutable medical records stored on distributed ledger technology, ensuring data integrity and preventing unauthorized modifications.",
  },
  {
    icon: Lock,
    title: "Patient-Centric Control",
    description: "Patients control who accesses their data through smart contract-based permissions with revocable access grants.",
  },
  {
    icon: Brain,
    title: "AI Diagnostics",
    description: "Advanced AI models analyze symptoms and medical history to suggest diagnoses and treatment options for rural providers.",
  },
  {
    icon: Globe,
    title: "FHIR Compliant",
    description: "Built on healthcare interoperability standards for seamless integration with existing systems worldwide.",
  },
  {
    icon: Wifi,
    title: "Offline Capable",
    description: "Continue working without internet connectivity with automatic synchronization when connection is restored.",
  },
  {
    icon: BarChart3,
    title: "Public Health Analytics",
    description: "Anonymized, aggregated data powers disease surveillance and resource allocation insights for health officials.",
  },
  {
    icon: UserCheck,
    title: "Decentralized Identity",
    description: "W3C-standard DIDs provide privacy-preserving authentication without centralized identity providers.",
  },
  {
    icon: FileText,
    title: "Complete Audit Trail",
    description: "Every access and modification is logged immutably, ensuring compliance and accountability.",
  },
];

const FeaturesSection = () => {
  return (
    <section id="features" className="py-20 md:py-28">
      <div className="container">
        <div className="mx-auto max-w-2xl text-center">
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Enterprise-Grade Healthcare Infrastructure
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            Built from the ground up for security, accessibility, and intelligence. 
            Every feature designed with rural healthcare challenges in mind.
          </p>
        </div>

        <div className="mt-16 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
          {features.map((feature, index) => (
            <Card 
              key={feature.title} 
              className="group relative overflow-hidden transition-all hover:shadow-lg hover:border-primary/50"
            >
              <CardHeader>
                <div className="mb-2 flex h-12 w-12 items-center justify-center rounded-lg bg-accent transition-colors group-hover:bg-primary">
                  <feature.icon className="h-6 w-6 text-accent-foreground transition-colors group-hover:text-primary-foreground" />
                </div>
                <CardTitle className="text-lg">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-sm">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturesSection;
