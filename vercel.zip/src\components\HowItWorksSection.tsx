import { Badge } from "@/components/ui/badge";

const steps = [
  {
    step: "01",
    title: "Provider Registration",
    description: "Healthcare providers register and receive a verified Decentralized Identifier (DID) for secure authentication.",
  },
  {
    step: "02",
    title: "Patient Enrollment",
    description: "Patients are enrolled with their own DID, granting them full control over their medical data access permissions.",
  },
  {
    step: "03",
    title: "Secure Data Entry",
    description: "Medical records are encrypted, hashed, and stored on the blockchain with actual files on decentralized storage.",
  },
  {
    step: "04",
    title: "AI-Assisted Care",
    description: "Providers leverage AI diagnostics for symptom analysis, image interpretation, and treatment recommendations.",
  },
  {
    step: "05",
    title: "Consent-Based Sharing",
    description: "Patients grant time-limited access to other providers via smart contracts, with full audit trails.",
  },
  {
    step: "06",
    title: "Analytics & Insights",
    description: "Anonymized data powers public health dashboards for disease surveillance and resource optimization.",
  },
];

const HowItWorksSection = () => {
  return (
    <section id="how-it-works" className="bg-muted/30 py-20 md:py-28">
      <div className="container">
        <div className="mx-auto max-w-2xl text-center">
          <Badge variant="outline" className="mb-4">How It Works</Badge>
          <h2 className="text-3xl font-bold tracking-tight sm:text-4xl">
            From Registration to Insights
          </h2>
          <p className="mt-4 text-lg text-muted-foreground">
            A seamless journey through our decentralized healthcare platform, 
            designed for simplicity without compromising security.
          </p>
        </div>

        <div className="mt-16 grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {steps.map((item, index) => (
            <div 
              key={item.step}
              className="group relative rounded-xl border bg-card p-6 transition-all hover:shadow-md"
            >
              <div className="mb-4 text-4xl font-bold text-primary/20 transition-colors group-hover:text-primary/40">
                {item.step}
              </div>
              <h3 className="mb-2 text-xl font-semibold">{item.title}</h3>
              <p className="text-muted-foreground">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default HowItWorksSection;
