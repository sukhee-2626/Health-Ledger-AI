import { Button } from "@/components/ui/button";
import { ArrowRight, Play, Shield, Brain, Lock } from "lucide-react";
import { Link } from "react-router-dom";
import heroImage from "@/assets/hero-healthcare.jpg";

const HeroSection = () => {
  return (
    <section className="relative overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src={heroImage}
          alt="Healthcare technology visualization"
          className="h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/95 to-background/70" />
      </div>

      <div className="container relative z-10 py-20 md:py-32">
        <div className="grid gap-10 lg:grid-cols-2 lg:gap-16">
          <div className="flex flex-col justify-center space-y-8">
            <div className="space-y-4">
              <div className="inline-flex items-center gap-2 rounded-full border border-primary/20 bg-primary/10 px-4 py-1.5 text-sm font-medium text-primary">
                <Shield className="h-4 w-4" />
                Blockchain-Powered Healthcare
              </div>
              <h1 className="text-4xl font-bold tracking-tight sm:text-5xl md:text-6xl">
                Secure Medical Records for{" "}
                <span className="text-primary">Rural Healthcare</span>
              </h1>
              <p className="max-w-xl text-lg text-muted-foreground">
                MediLedger AI combines blockchain security with AI-powered diagnostics 
                to transform healthcare delivery in underserved communities. Patient-controlled, 
                immutable, and intelligent.
              </p>
            </div>

            <div className="flex flex-col gap-4 sm:flex-row">
              <Button size="lg" asChild className="gap-2">
                <Link to="/auth">
                  Hospital / Provider Login
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
              <Button size="lg" variant="outline" asChild className="gap-2">
                <Link to="/patient-auth">
                  Patient Login
                  <ArrowRight className="h-4 w-4" />
                </Link>
              </Button>
            </div>

            <div className="flex flex-wrap items-center gap-8 pt-4">
              <div className="flex items-center gap-2">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent">
                  <Lock className="h-5 w-5 text-accent-foreground" />
                </div>
                <div>
                  <p className="text-sm font-semibold">End-to-End Encrypted</p>
                  <p className="text-xs text-muted-foreground">HIPAA Compliant</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-accent">
                  <Brain className="h-5 w-5 text-accent-foreground" />
                </div>
                <div>
                  <p className="text-sm font-semibold">AI Diagnostics</p>
                  <p className="text-xs text-muted-foreground">95% Accuracy</p>
                </div>
              </div>
            </div>
          </div>

          <div className="hidden lg:flex lg:items-center lg:justify-center">
            {/* Stats Cards */}
            <div className="grid gap-4">
              <div className="rounded-xl border bg-card/80 p-6 backdrop-blur">
                <p className="text-3xl font-bold text-primary">50K+</p>
                <p className="text-sm text-muted-foreground">Patient Records Secured</p>
              </div>
              <div className="rounded-xl border bg-card/80 p-6 backdrop-blur">
                <p className="text-3xl font-bold text-primary">200+</p>
                <p className="text-sm text-muted-foreground">Rural Clinics Connected</p>
              </div>
              <div className="rounded-xl border bg-card/80 p-6 backdrop-blur">
                <p className="text-3xl font-bold text-primary">99.9%</p>
                <p className="text-sm text-muted-foreground">Uptime Guaranteed</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
