import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import FeaturesSection from "@/components/FeaturesSection";
import HowItWorksSection from "@/components/HowItWorksSection";
import PersonasSection from "@/components/PersonasSection";
import CTASection from "@/components/CTASection";
import Footer from "@/components/Footer";
import { Helmet } from "react-helmet-async";

const Index = () => {
  return (
    <>
      <Helmet>
        <title>MediLedger AI - Blockchain-Powered Healthcare for Rural Communities</title>
        <meta 
          name="description" 
          content="MediLedger AI combines blockchain security with AI-powered diagnostics to transform healthcare delivery in underserved rural communities. Patient-controlled, immutable, and intelligent medical records." 
        />
      </Helmet>
      <div className="min-h-screen bg-background">
        <Navbar />
        <main>
          <HeroSection />
          <FeaturesSection />
          <HowItWorksSection />
          <PersonasSection />
          <CTASection />
        </main>
        <Footer />
      </div>
    </>
  );
};

export default Index;
